import model
print('aa')