import sys
from scrapy.cmdline import execute
execute(["scrapy", "crawl", 'news'])
