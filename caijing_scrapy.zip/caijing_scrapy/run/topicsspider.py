# -*- coding: utf-8 -*-

#通过python脚本启动scrapy
import sys
for arg in sys.argv:
    print(arg)
